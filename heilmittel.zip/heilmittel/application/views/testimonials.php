<!--************************************
		Testimonials Start
*************************************-->
<section class="th-sectionspace th-haslayout th-parallaximg th-darkoverlay" data-appear-top-offset="600" data-parallax="scroll" data-image-src="<?php echo base_url();?>assets/images/bgparallax/bgparallax-02.jpg">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-xs-12">
				<div class="th-testimonials">
					<div class="th-sectionhead">
						<div class="th-sectiontitle">
							<h2>Words of <span>Satisfaction</span></h2>
						</div>
					</div>
					<div id="th-testimonialslider" class="th-testimonialslider"></div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--************************************
		Testimonials End
*************************************-->